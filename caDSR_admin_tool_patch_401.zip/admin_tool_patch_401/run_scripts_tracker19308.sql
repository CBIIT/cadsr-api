
-- Connect as sbr and run the following script
set define on
set scan on
set define '&'
connect sbr/&sbr_pass@&conn_str

set echo off
set define off
set scan off

spool logs/run_scripts_tracker19308.log
  @GF19308/META_UI.pkb
  

set define on
set scan on
spool off

