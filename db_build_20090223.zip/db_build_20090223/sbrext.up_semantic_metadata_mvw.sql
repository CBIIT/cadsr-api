DROP MATERIALIZED VIEW SBREXT.UP_SEMANTIC_METADATA_MVW;
CREATE MATERIALIZED VIEW SBREXT.UP_SEMANTIC_METADATA_MVW 
TABLESPACE SBREXT
NOCACHE
LOGGING
NOCOMPRESS
NOPARALLEL
BUILD IMMEDIATE
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS 
/* Formatted on 2008/10/07 16:06 (Formatter Plus v4.8.8) */
SELECT CAST (admincomponent_crud.cmr_guid AS CHAR (36)) sm_idseq,
       con.con_idseq, con.preferred_name concept_code,
       con.long_name concept_name,
       con.preferred_definition concept_definition,
       DECODE (cc.primary_flag_ind, 'Yes', 1, 0) primary_concept,
       cc.display_order, cl.component_level, cs.cs_idseq cs_idseq,
       cp_idseq cp_idseq, NULL cm_idseq, NULL am_idseq, NULL at_idseq,
       NULL te_idseq, NULL asm_idseq, CAST (NULL AS CHAR (36)) ocr_idseq,
       CAST (NULL AS CHAR (36)) oc_idseq, NULL prop_idseq, NULL vd_idseq,
       NULL short_meaning, cs.cs_id public_id, cs.VERSION
  FROM concepts_ext con,
       component_concepts_ext cc,
       component_levels_ext cl,
       classification_schemes cs,
       up_cadsr_project_mvw cp
 WHERE cs.condr_idseq = cc.condr_idseq
   AND cc.con_idseq = con.con_idseq
   AND cc.cl_idseq = cl.cl_idseq(+)
   AND cs.cs_idseq = cp.cs_idseq
UNION
SELECT CAST (admincomponent_crud.cmr_guid AS CHAR (36)) sm_idseq,
       con.con_idseq, con.preferred_name concept_code,
       con.long_name concept_name,
       con.preferred_definition concept_definition,
       DECODE (cc.primary_flag_ind, 'Yes', 1, 0), cc.display_order,
       cl.component_level, NULL cs_idseq, cp_idseq, cm_idseq, NULL am_idseq,
       NULL at_idseq, NULL te_idseq, CAST (NULL AS CHAR (36)) asm_idseq,
       CAST (NULL AS CHAR (36)) ocr_idseq, oc.oc_idseq oc_idseq,
       NULL prop_idseq, NULL vd_idseq, NULL short_meaning, oc.oc_id public_id,
       oc.VERSION
  FROM concepts_ext con,
       component_concepts_ext cc,
       component_levels_ext cl,
       up_class_metadata_mvw cm,
       object_classes_ext oc
 WHERE cm.oc_idseq = oc.oc_idseq
   AND oc.condr_idseq = cc.condr_idseq
   AND cc.con_idseq = con.con_idseq
   AND cc.cl_idseq = cl.cl_idseq(+)
UNION
SELECT CAST (admincomponent_crud.cmr_guid AS CHAR (36)) sm_idseq,
       con.con_idseq, con.preferred_name concept_code,
       con.long_name concept_name,
       con.preferred_definition concept_definition,
       DECODE (cc.primary_flag_ind, 'Yes', 1, 0), cc.display_order,
       cl.component_level, NULL cs_idseq, cp_idseq, NULL cm_idseq, am_idseq,
       NULL at_idseq, NULL te_idseq, NULL asm_idseq,
       CAST (NULL AS CHAR (36)) ocr_idseq, CAST (NULL AS CHAR (36)) oc_idseq,
       prop.prop_idseq prop_idseq, NULL vd_idseq, NULL short_meaning,
       prop.prop_id public_id, prop.VERSION
  FROM concepts_ext con,
       component_concepts_ext cc,
       component_levels_ext cl,
       up_attribute_metadata_mvw cm,
       properties_ext prop
 WHERE cm.prop_idseq = prop.prop_idseq
   AND prop.condr_idseq = cc.condr_idseq
   AND cc.con_idseq = con.con_idseq
   AND cc.cl_idseq = cl.cl_idseq(+)
UNION
SELECT CAST (admincomponent_crud.cmr_guid AS CHAR (36)) sm_idseq,
       con.con_idseq, con.preferred_name concept_code,
       con.long_name concept_name,
       con.preferred_definition concept_definition,
       DECODE (cc.primary_flag_ind, 'Yes', 1, 0), cc.display_order,
       cl.component_level, NULL cs_idseq, NULL cp_idseq, NULL cm_idseq,
       NULL am_idseq, at_idseq, NULL te_idseq,
       CAST (NULL AS CHAR (36)) asm_idseq, CAST (NULL AS CHAR (36)) ocr_idseq,
       NULL oc_idseq, NULL prop_idseq, vd.vd_idseq vd_idseq,
       NULL short_meaning, vd.vd_id public_id, vd.VERSION
  FROM concepts_ext con,
       component_concepts_ext cc,
       component_levels_ext cl,
       up_attribute_type_metadata_mvw cm,
       value_domains vd
 WHERE cm.vd_idseq = vd.vd_idseq
   AND vd.condr_idseq = cc.condr_idseq
   AND cc.con_idseq = con.con_idseq
   AND cc.cl_idseq = cl.cl_idseq(+)
UNION
SELECT CAST (admincomponent_crud.cmr_guid AS CHAR (36)) sm_idseq,
       con.con_idseq, con.preferred_name concept_code,
       con.long_name concept_name,
       con.preferred_definition concept_definition,
       DECODE (cc.primary_flag_ind, 'Yes', 1, 0), cc.display_order,
       cl.component_level, NULL cs_idseq, NULL cp_idseq, NULL cm_idseq,
       NULL am_idseq, NULL at_idseq, te_idseq,
       CAST (NULL AS CHAR (36)) asm_idseq, CAST (NULL AS CHAR (36)) ocr_idseq,
       NULL oc_idseq, NULL prop_idseq, NULL vd_idseq,
       vm.long_name short_meaning, vm.vm_id public_id, vm.VERSION
  FROM concepts_ext con,
       component_concepts_ext cc,
       component_levels_ext cl,
       up_type_enumeration_mvw cm,
       value_meanings vm
 WHERE cm.vm_idseq = vm.vm_idseq
   AND vm.condr_idseq = cc.condr_idseq
   AND cc.con_idseq = con.con_idseq
   AND cc.cl_idseq = cl.cl_idseq(+);

COMMENT ON MATERIALIZED VIEW SBREXT.UP_SEMANTIC_METADATA_MVW IS 'snapshot table for snapshot SBREXT.UP_SEMANTIC_METADATA_MVW';

