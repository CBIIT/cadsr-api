
-- Connect as sbrext and run the following script
set define on
set scan on
set define '&'
connect sbr/&sbr_pass@&conn_str

set echo off
set define off
set scan off
spool logs/run_scripts_tracker18836.log
  @CD_BASIC_SEARCH$CDV_new.pkb
spool off

