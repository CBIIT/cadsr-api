-- Patch upgrade instructions (as of Feb 23, 2009)

   -- Using SQL*Plus compatible with Oracle10g 

set define on
set scan on
set define '&'
prompt Please enter database SID
define conn_str = &conn_str
prompt Please enter SBR password
define sbr_pass = &sbr_pass
prompt Please enter SBREXT password
define sbrext_pass = &sbrext_pass

-- GF 17103: Create a View for the UML_LOADER_DEFAULTS table 
@run_scripts_tracker17103.sql

-- GF 17293: Fix Missing Public Ids Issue and add NOT NULL constraint on PUBLIC ID 
@run_scripts_tracker17293.sql

-- GF 17418: Change privileges granted to the DER_USER Role 
@run_scripts_tracker17418.sql

-- GF 17672 (Task 2788): Add new GME Name Space fields to UML Browser Materialized views 
@run_scripts_tracker17672.sql

-- GF 18435: Add NOT NULL and UNIQUE Constraints for tool_name and property on Tool Options table 
@run_scripts_tracker18435.sql

-- GF 18718: Fix Form Builder Error caused by NOT NULL Public ID change 
@run_scripts_tracker18718.sql

-- GF 18836: Fix Conceptual Domain Searches not returning on Admin Tool
-- @run_scripts_tracker18836.sql

-- GF 4612: Fix EVS Source field on Concept Tree from the Admin Tool
-- @run_scripts_tracker4612.sql

-- GF 16980 Task 2772:Remove uncompiled objects from the caDSR Database
@run_scripts_tracker16980_task2772.sql




