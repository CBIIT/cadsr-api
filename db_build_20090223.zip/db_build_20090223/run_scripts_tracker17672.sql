-- Run as SBREXT
set define on
set scan on
set define '&'
connect sbrext/&sbrext_pass@&conn_str

spool logs/tracker_17672_driver_script.log

set timing on
set echo off

-- Drop and recreate the Mviews
@buildall_sbrext_mviews_tracker_17672.sql
@grants_for_4003_Mviews.sql

-- Refresh all the Mviews
@Refresh_Mviews.sql

spool off












