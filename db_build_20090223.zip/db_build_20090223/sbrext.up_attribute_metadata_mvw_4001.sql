DROP MATERIALIZED VIEW SBREXT.UP_ATTRIBUTE_METADATA_MVW;

CREATE MATERIALIZED VIEW sbrext.up_attribute_metadata_mvw
NOCACHE
LOGGING
NOCOMPRESS
NOPARALLEL
BUILD IMMEDIATE
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS
SELECT uat.am_idseq, uat.NAME, uat.description, uat.de_idseq, uat.pg_idseq,
       uat.cs_idseq, uat.desig_idseq, uat.defin_idseq, uat.cs_csi_idseq,
       uat.dec_idseq, uat.vd_idseq, uat.fully_qualified_name, uat.cm_idseq,
       uat.prop_idseq, uat.cp_idseq, AT.at_idseq, uat.gmexmllocreference,
       uat.VERSION, uat.public_id, uat.class_gmexmlelement, uat.class_gmenamespace
  FROM sbrext.up_attribute_metadata_mvw_temp uat, sbrext.up_attribute_type_metadata_mvw AT
 WHERE uat.am_idseq = AT.am_idseq;

GRANT ALTER, DELETE, INSERT, SELECT, UPDATE, ON COMMIT REFRESH, QUERY REWRITE, DEBUG, FLASHBACK ON SBREXT.UP_ATTRIBUTE_METADATA_MVW TO DER_USER;

GRANT ALTER, DELETE, INSERT, SELECT, UPDATE, ON COMMIT REFRESH, QUERY REWRITE, DEBUG, FLASHBACK ON SBREXT.UP_ATTRIBUTE_METADATA_MVW TO LOADER_ROLE;

COMMENT ON MATERIALIZED VIEW SBREXT.UP_ATTRIBUTE_METADATA_MVW IS 'snapshot table for snapshot SBREXT.UP_ATTRIBUTE_METADATA_MVW';

