set echo off
set pagesize 0
set linesize 200
set verify off
set feedback off
set timing off
set time off
spool logs/revoke_sbrext_der_user_privs.out

-- Revoke Privileges from DER_USER 
select 'revoke DEBUG ON SBREXT.'||object_name||' FROM der_user;'
from user_objects
  where object_type in ('PACKAGE', 'PROCEDURE', 'FUNCTION', 'TYPE', 'VIEW', 'TABLE', 'MATERIALIZED VIEW');

select 'revoke EXECUTE ON SBREXT.'||object_name||' FROM der_user;'
from user_objects
  where object_type in ('PROCEDURE', 'FUNCTION');

select 'revoke ALTER ON SBREXT.'||object_name||' FROM der_user;'
from user_objects
  where object_type = 'SEQUENCE';

select 'revoke ALTER ON SBREXT.'||object_name||' FROM der_user;'
from user_objects
  where object_type IN ('TABLE', 'MATERIALIZED VIEW');

select 'revoke ON COMMIT REFRESH ON SBREXT.'||object_name||' FROM der_user;'
from user_objects
  where object_type IN ('TABLE', 'MATERIALIZED VIEW');

select 'revoke FLASHBACK ON SBREXT.'||object_name||' FROM der_user;'
from user_objects
  where object_type IN ('TABLE', 'MATERIALIZED VIEW');

select 'revoke QUERY REWRITE ON SBREXT.'||object_name||' FROM der_user;'
from user_objects
  where object_type IN ('TABLE', 'MATERIALIZED VIEW');

select 'revoke UPDATE ON SBREXT.'||object_name||' FROM der_user;'
from user_objects
  where object_type = 'MATERIALIZED VIEW';

select 'revoke INSERT ON SBREXT.'||object_name||' FROM der_user;'
from user_objects
  where object_type = 'MATERIALIZED VIEW';

select 'revoke DELETE ON SBREXT.'||object_name||' FROM der_user;'
from user_objects
  where object_type = 'MATERIALIZED VIEW';

select 'revoke ALTER ON SBREXT.'||object_name||' FROM der_user;'
from user_objects
  where object_type = 'VIEW';

select 'revoke ON COMMIT REFRESH ON SBREXT.'||object_name||' FROM der_user;'
from user_objects
  where object_type = 'VIEW';

select 'revoke FLASHBACK ON SBREXT.'||object_name||' FROM der_user;'
from user_objects
  where object_type = 'VIEW';

select 'revoke QUERY REWRITE ON SBREXT.'||object_name||' FROM der_user;'
from user_objects
  where object_type = 'VIEW';

spool off
set feedback on
set verify on

spool logs/revoke_sbrext_der_user_privs_out.log
@logs/revoke_sbrext_der_user_privs.out
Spool off


