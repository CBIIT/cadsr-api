DROP MATERIALIZED VIEW SBREXT.UP_CADSR_PROJECT_MVW;
CREATE MATERIALIZED VIEW SBREXT.UP_CADSR_PROJECT_MVW 
TABLESPACE SBREXT
NOCACHE
LOGGING
NOCOMPRESS
NOPARALLEL
BUILD IMMEDIATE
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS 
/* Formatted on 2008/10/07 16:06 (Formatter Plus v4.8.8) */
SELECT cs_idseq, cs_idseq cp_idseq, preferred_name short_name,
       long_name long_name, preferred_definition description, VERSION,
       a.NAME gmenamespace, c.cs_id public_id
  FROM classification_schemes c,
       (SELECT ac_idseq, NAME
          FROM designations
         WHERE detl_name = 'GME_XMLNamespace') a
 WHERE cstl_name = 'Project' AND c.cs_idseq = a.ac_idseq(+);

COMMENT ON MATERIALIZED VIEW SBREXT.UP_CADSR_PROJECT_MVW IS 'snapshot table for snapshot SBREXT.UP_CADSR_PROJECT_MVW';

