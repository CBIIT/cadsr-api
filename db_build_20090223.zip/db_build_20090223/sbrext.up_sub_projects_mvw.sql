DROP MATERIALIZED VIEW SBREXT.UP_SUB_PROJECTS_MVW;
CREATE MATERIALIZED VIEW SBREXT.UP_SUB_PROJECTS_MVW 
TABLESPACE SBREXT
NOCACHE
LOGGING
NOCOMPRESS
NOPARALLEL
BUILD IMMEDIATE
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS 
/* Formatted on 2008/10/07 16:06 (Formatter Plus v4.8.8) */
SELECT CAST (admincomponent_crud.cmr_guid AS CHAR (36)) sp_idseq,
       csi.long_name sub_project_name,
       csi.preferred_definition sub_project_description, cs.cs_idseq,
       cs_csi_idseq, cp.cp_idseq, csi.VERSION, csi.csi_id public_id
  FROM classification_schemes cs,
       cs_csi cscsi,
       cs_items csi,
       up_cadsr_project_mvw cp
 WHERE cs.cs_idseq = cscsi.cs_idseq
   AND cscsi.csi_idseq = csi.csi_idseq
   AND csitl_name = 'UML_PACKAGE_ALIAS'
   AND cs.cs_idseq = cp.cp_idseq;

COMMENT ON MATERIALIZED VIEW SBREXT.UP_SUB_PROJECTS_MVW IS 'snapshot table for snapshot SBREXT.UP_SUB_PROJECTS_MVW';

