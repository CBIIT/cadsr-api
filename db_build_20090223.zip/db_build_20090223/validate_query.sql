-- Count of invalid objects owned by user, excluding synonyms
   -- Run as SBR, then as SBREXT
prompt ***** Count of Invalid Objects by type ******
SELECT   object_type, COUNT (*)
    FROM user_objects
   WHERE object_type NOT IN ('SYNONYM') 
     AND status = 'INVALID'
GROUP BY object_type
order by object_type;

