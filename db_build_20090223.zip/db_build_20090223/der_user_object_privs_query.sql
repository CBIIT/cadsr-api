SELECT DISTINCT grantee, obj.object_type, privs.privilege
FROM user_tab_privs privs, user_objects obj
WHERE     privs.table_name = obj.object_name
      AND privs.grantee = 'DER_USER'
ORDER BY grantee, obj.object_type, privs.privilege;