-- Count of invalid objects owned by user, excluding synonyms
   -- Run as SBR, then as SBREXT
SELECT   object_type, COUNT (*)
    FROM user_objects
   WHERE object_type != 'SYNONYM' AND status = 'INVALID'
GROUP BY object_type;
