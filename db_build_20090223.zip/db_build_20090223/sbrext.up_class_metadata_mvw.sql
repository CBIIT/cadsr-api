DROP MATERIALIZED VIEW SBREXT.UP_CLASS_METADATA_MVW;
CREATE MATERIALIZED VIEW SBREXT.UP_CLASS_METADATA_MVW 
TABLESPACE SBREXT
NOCACHE
LOGGING
NOCOMPRESS
NOPARALLEL
BUILD IMMEDIATE
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS 
/* Formatted on 2008/10/07 16:06 (Formatter Plus v4.8.8) */
SELECT cmt.cm_idseq, cmt.NAME, cmt.description, cmt.oc_idseq, cmt.pg_idseq,
       cmt.cs_idseq, cmt.desig_idseq, cmt.defin_idseq, cmt.cs_csi_idseq,
       cmt.fully_qualified_class_name, cmt.cp_idseq, gm.gm_idseq,
       cmt.gmenamespace, cmt.gmexmlelement, cmt.VERSION, cmt.public_id
  FROM up_class_metadata_mvw_temp cmt, up_gen_metadata_mvw gm
 WHERE cmt.cm_idseq = gm.s_cm_idseq(+)
       AND cmt.cp_idseq = NVL (gm.cp_idseq, cmt.cp_idseq);

COMMENT ON MATERIALIZED VIEW SBREXT.UP_CLASS_METADATA_MVW IS 'snapshot table for snapshot SBREXT.UP_CLASS_METADATA_MVW';

