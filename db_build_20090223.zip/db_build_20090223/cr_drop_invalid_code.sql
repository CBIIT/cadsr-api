/* 
REM  cr_drop_invalid.sql
REM: Original author: Michael Martin, Oracle Corporation
REM: Usage:
REM:   Connect as ** schema owner **
REM:   Run script
REM:   execute drop_invalid_code.sql script (@drop_invalid_code.sql) from SQL*Plus prompt
*/

set echo off
set feed off
set pages 0
spool drop_invalid_code.sql

select 'drop '|| object_type|| ' '|| object_name||';'
from user_objects
where status = 'INVALID'
  and object_type in 
('PROCEDURE', 'FUNCTION', 'VIEW', 'PACKAGE', 'PACKAGE BODY', 'TRIGGER', 'TYPE')
order by object_type desc, object_name
/

spool off

set pages 34
set feed on
set head on

@drop_invalid_code.sql

