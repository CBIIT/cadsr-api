
-- 1st Update
UPDATE concepts_view_ext c1
   SET evs_source =
          DECODE (UPPER (origin),
                  'NCI THESAURUS', 'NCI_CONCEPT_CODE',
                  'NCI METATHESAURUS', 'UMLS_CUI',
                  'GO', 'GO_CODE',
                  'VA_NDFRT', 'VA_NDF_CODE',
                  'UWD_VISUAL_ANATOMIST', 'UWD_VA_CODE',
                  'LOINC', 'LOINC_CODE',
                  'MGED', 'NCI_MO_CODE',
                  'MEDDRA', 'MEDDRA_CODE',
                  'SNOMED', 'SNOMED_CODE',
                  'ZEBRAFISH', 'ZEBRAFISH_CODE',
                  'UNKNOWN SOURCE'
                 );

-- 2nd update          
UPDATE concepts_view_ext c1
   SET evs_source = 'NCI_META_CUI'
 WHERE UPPER (origin) = 'NCI METATHESAURUS'
   AND SUBSTR (preferred_name, 1, 2) = 'CL';

COMMIT ;