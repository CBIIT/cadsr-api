
-- Connect as sbrext and run the following script
set define on
set scan on
set define '&'
connect sbrext/&sbrext_pass@&conn_str

set echo off
spool logs/run_scripts_tracker4612.log

-- Connect as sbrext and run the following scripts
@EVS_SOURCE_cleanup.sql

set define off
@SBREXT_CON_IRUD$CON_FIX.pkb

spool off


