DROP MATERIALIZED VIEW SBREXT.UP_ATTRIBUTE_TYPE_METADATA_MVW;
CREATE MATERIALIZED VIEW SBREXT.UP_ATTRIBUTE_TYPE_METADATA_MVW 
TABLESPACE SBREXT
NOCACHE
LOGGING
NOCOMPRESS
NOPARALLEL
BUILD IMMEDIATE
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS 
/* Formatted on 2008/10/07 16:06 (Formatter Plus v4.8.8) */
SELECT CAST (admincomponent_crud.cmr_guid AS CHAR (36)) at_idseq, am.am_idseq,
       am.de_idseq, am.vd_idseq, vd.dtl_name vd_datatype,
       vd.long_name vd_long_name, vd.vd_id public_id, vd.VERSION VERSION
  FROM up_attribute_metadata_mvw_temp am, value_domains vd
 WHERE am.vd_idseq = vd.vd_idseq;

COMMENT ON MATERIALIZED VIEW SBREXT.UP_ATTRIBUTE_TYPE_METADATA_MVW IS 'snapshot table for snapshot SBREXT.UP_ATTRIBUTE_TYPE_METADATA_MVW';

