DROP MATERIALIZED VIEW SBREXT.UP_TYPE_ENUMERATION_MVW;
CREATE MATERIALIZED VIEW SBREXT.UP_TYPE_ENUMERATION_MVW 
TABLESPACE SBREXT
NOCACHE
LOGGING
NOCOMPRESS
NOPARALLEL
BUILD IMMEDIATE
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS 
/* Formatted on 2008/10/07 16:06 (Formatter Plus v4.8.8) */
SELECT CAST (admincomponent_crud.cmr_guid AS CHAR (36)) te_idseq, AT.at_idseq,
       pv.VALUE, vm.long_name short_meaning, vp.vp_idseq, vp.pv_idseq,
       vm.vm_idseq, AT.VERSION, AT.public_id
  FROM up_attribute_type_metadata_mvw AT,
       vd_pvs vp,
       permissible_values pv,
       value_meanings vm
 WHERE AT.vd_idseq = vp.vd_idseq
   AND vp.pv_idseq = pv.pv_idseq
   AND pv.vm_idseq = vm.vm_idseq;

COMMENT ON MATERIALIZED VIEW SBREXT.UP_TYPE_ENUMERATION_MVW IS 'snapshot table for snapshot SBREXT.UP_TYPE_ENUMERATION_MVW';

