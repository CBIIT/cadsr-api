set echo off
set pagesize 0
set linesize 200
set verify off
set feedback off
set timing off
set time off
spool logs/revoke_sbr_der_user_privs.out

-- Revoke Privileges from DER_USER 
select 'revoke DEBUG ON SBR.'||object_name||' FROM der_user;'
from user_objects
  where object_type in ('PACKAGE', 'PROCEDURE', 'FUNCTION', 'TYPE', 'VIEW');

select 'revoke EXECUTE ON SBR.'||object_name||' FROM der_user;'
from user_objects
  where object_type in ('PROCEDURE', 'FUNCTION');

select 'revoke ALTER ON SBR.'||object_name||' FROM der_user;'
from user_objects
  where object_type = 'VIEW';

select 'revoke ON COMMIT REFRESH ON SBR.'||object_name||' FROM der_user;'
from user_objects
  where object_type = 'VIEW';

select 'revoke FLASHBACK ON SBR.'||object_name||' FROM der_user;'
from user_objects
  where object_type = 'VIEW';

select 'revoke QUERY REWRITE ON SBR.'||object_name||' FROM der_user;'
from user_objects
  where object_type = 'VIEW';

spool off
set feedback on
set verify on

spool logs/revoke_sbr_der_user_privs_out.log
@logs/revoke_sbr_der_user_privs.out
Spool off


