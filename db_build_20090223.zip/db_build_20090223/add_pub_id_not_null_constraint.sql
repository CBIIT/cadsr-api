-- Add NOT NULL constraints to the public ID fields on the AC table and the original tables for each AC type

-- Connect as sbr and run the following statements
set define on
set scan on
set define '&'
connect sbr/&sbr_pass@&conn_str

-- ADMINISTERED_COMPONENTS
ALTER TABLE sbr.administered_components
  MODIFY public_id NOT NULL;
   
-- DATA ELEMENTS
ALTER TABLE sbr.data_elements
  MODIFY cde_id NOT NULL;
  
-- CONCEPTUAL DOMAINS
ALTER TABLE sbr.conceptual_domains
  MODIFY cd_id NOT NULL;
  
-- DATA ELEMENT CONCEPTS
ALTER TABLE sbr.data_element_concepts
  MODIFY dec_id NOT NULL;
  
-- CLASSIFICATIONS
ALTER TABLE sbr.classification_schemes
  MODIFY cs_id NOT NULL;
  
-- CLASSIFICATION SCHEME ITEMS
-- ALTER TABLE sbr.cs_items
--  MODIFY csi_id NOT NULL;
  
-- VALUE MEANINGS
ALTER TABLE sbr.value_meanings
  MODIFY vm_id NOT NULL;
  
-- VALUE DOMAINS
ALTER TABLE sbr.value_domains
  MODIFY vd_id NOT NULL;
  

-- Connect as sbrext and run the following statements
set define on
set scan on
set define '&'
connect sbrext/&sbrext_pass@&conn_str
                  
-- OBLECT_CLASS
ALTER TABLE sbrext.object_classes_ext
  MODIFY oc_id NOT NULL;
  
-- CONCEPTS
ALTER TABLE sbrext.concepts_ext
  MODIFY con_id NOT NULL;

-- PROPERTIES
ALTER TABLE sbrext.properties_ext
  MODIFY prop_id NOT NULL;
  
--  QUEST_CONTENTS
ALTER TABLE sbrext.quest_contents_ext
  MODIFY qc_id NOT NULL;
  
-- PROTOCOLS
ALTER TABLE sbrext.protocols_ext
  MODIFY proto_id NOT NULL;
  
--  REPRESENTATIONS
ALTER TABLE sbrext.representations_ext
  MODIFY rep_id NOT NULL;
  
--  OBJECT CLASS RECS
ALTER TABLE sbrext.oc_recs_ext
  MODIFY ocr_id NOT NULL;