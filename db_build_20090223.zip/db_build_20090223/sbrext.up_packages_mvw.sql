DROP MATERIALIZED VIEW SBREXT.UP_PACKAGES_MVW;
CREATE MATERIALIZED VIEW SBREXT.UP_PACKAGES_MVW 
TABLESPACE SBREXT
NOCACHE
LOGGING
NOCOMPRESS
NOPARALLEL
BUILD IMMEDIATE
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS 
/* Formatted on 2008/10/07 16:06 (Formatter Plus v4.8.8) */
SELECT UP.pg_idseq, UP.NAME, UP.description, UP.cs_idseq, UP.cs_csi_idseq,
       UP.cp_idseq, sp.sp_idseq, UP.gmenamespace, UP.VERSION, UP.public_id,
       UP.package_type
  FROM up_packages_mvw_temp UP, up_sub_projects_mvw sp
 WHERE UP.p_cs_csi_idseq = sp.cs_csi_idseq(+);

COMMENT ON MATERIALIZED VIEW SBREXT.UP_PACKAGES_MVW IS 'snapshot table for snapshot SBREXT.UP_PACKAGES_MVW';

