/* 
REM  cr_revoke_exec_proc.sql
REM: Usage:
REM:   Connect as ** schema owner **
REM:   Run script
REM:   cr_revoke_exec_proc.sql (@grant_exec_proc.sql) from SQL*Plus prompt
*/

set echo off
set feed off
set pages 0
spool revoke_exec_proc.sql

select 'revoke execute on '|| object_name|| ' from DER_USER;'
from user_objects
where object_type ='PROCEDURE'
order by object_type desc, object_name;


spool off

set pages 34
set feed on
set head on

@revoke_exec_proc.sql

