
-- Connect as sbr and run the following scripts
set define on
set scan on
set define '&'
connect sbr/&sbr_pass@&conn_str
-- Before validation log
spool logs/before_validation_tracker17293.log
  @ac_missing_public_ids_val.sql
spool off

-- Run the change scripts
spool logs/run_change_scripts_tracker17293.log
  @update_orphan_acs.sql  
  @update_27_cs_acs.sql  
  @add_pub_id_not_null_constraint.sql
spool off

-- after validation log
spool logs/after_validation_tracker17293.log
  @ac_missing_public_ids_val.sql
spool off

    





