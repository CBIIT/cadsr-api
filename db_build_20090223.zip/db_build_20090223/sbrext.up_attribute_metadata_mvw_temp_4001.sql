DROP MATERIALIZED VIEW sbrext.up_attribute_metadata_mvw_temp;

CREATE MATERIALIZED VIEW sbrext.up_attribute_metadata_mvw_temp
NOCACHE
LOGGING
NOCOMPRESS
NOPARALLEL
BUILD IMMEDIATE
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS
SELECT CAST (sbr.admincomponent_crud.cmr_guid AS CHAR (36)) am_idseq,
       substr (dedes.name, instr (dedes.name, '.',-1)+1) NAME,
       defin.definition description, de.de_idseq, pg.pg_idseq, cscsi.cs_idseq,
       dedes.desig_idseq, defin.defin_idseq, pg.cs_csi_idseq, DEC.dec_idseq,
       de.vd_idseq, /*fully_qualified_class_name||'.'||dedes.name*/ dedes.NAME
                                                         fully_qualified_name,
       cm_idseq, DEC.prop_idseq, cp.cp_idseq,
       sbrext.umlproject_routines.get_gmename
                                   (de.de_idseq,
                                    'GME_XMLLocReference',
                                    cscsi.cs_csi_idseq
                                   ) gmexmllocreference,
       de.VERSION, de.cde_id public_id,
       uc.gmexmlelement AS class_gmexmlelement,
       uc.gmenamespace AS class_gmenamespace
  FROM sbr.data_element_concepts DEC,
       sbrext.up_class_metadata_mvw uc,
       sbr.ac_csi accsi,
       sbrext.up_packages_mvw pg,
       sbrext.up_cadsr_project_mvw cp,
       sbr.cs_csi cscsi,
       (SELECT *
          FROM sbr.designations
         WHERE                             --detl_name =  'UML Class:UML Attr'
               detl_name = 'UML Qualified Attr') dedes,
       sbrext.ac_att_cscsi_ext descsi,
       sbrext.ac_att_cscsi_ext defcsi,
       sbr.data_elements de,
       (SELECT defin_idseq, definition, ac_idseq
          FROM sbr.definitions
         WHERE defl_name = 'UML Class:UML Attr') defin
 WHERE uc.oc_idseq = DEC.oc_idseq
   AND DEC.dec_idseq = de.dec_idseq
   AND de.de_idseq = defin.ac_idseq(+)
   AND de.de_idseq = dedes.ac_idseq
   AND accsi.ac_idseq = de.de_idseq
   AND cscsi.cs_csi_idseq = accsi.cs_csi_idseq
   AND descsi.att_idseq = dedes.desig_idseq
   AND defcsi.att_idseq(+) = defin.defin_idseq
   AND (    pg.cs_csi_idseq = descsi.cs_csi_idseq
        AND pg.cs_csi_idseq(+) = defcsi.cs_csi_idseq
        AND pg.cs_csi_idseq = accsi.cs_csi_idseq
       )
   AND cscsi.cs_idseq = cp.cp_idseq
   AND uc.cs_idseq = cscsi.cs_idseq
   AND uc.cs_csi_idseq = cscsi.cs_csi_idseq;

COMMENT ON MATERIALIZED VIEW SBREXT.UP_ATTRIBUTE_METADATA_MVW_TEMP IS 'snapshot table for snapshot SBREXT.UP_ATTRIBUTE_METADATA_MVW_TEMP';

GRANT ALTER, DELETE, INSERT, SELECT, UPDATE, ON COMMIT REFRESH, QUERY REWRITE, DEBUG, FLASHBACK ON SBREXT.UP_ATTRIBUTE_METADATA_MVW_TEMP TO LOADER_ROLE;