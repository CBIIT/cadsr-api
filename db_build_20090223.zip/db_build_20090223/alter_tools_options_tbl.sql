-- Run as SBREXT
ALTER TABLE sbrext.tool_options_ext
modify (tool_name not null);

ALTER TABLE sbrext.tool_options_ext
modify (property not null);

ALTER TABLE sbrext.tool_options_ext
ADD CONSTRAINT tool_options_uniq UNIQUE (tool_name, property);