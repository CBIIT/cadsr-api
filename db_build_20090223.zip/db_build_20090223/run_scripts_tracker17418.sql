
-- Connect as sbr and run the following scripts
set define on
set scan on
set define '&'
connect sbr/&sbr_pass@&conn_str
spool logs/before_der_user_sbr_privs_list.log
@der_user_object_privs_query.sql
spool off

-- revoke der_user SBR privileges
@revoke_sbr_der_user_privs.sql

spool logs/after_der_user_sbr_privs_list.log
@der_user_object_privs_query.sql
spool off

-- Connect as sbrext and run the following scripts
set define on
set scan on
set define '&'
connect sbrext/&sbrext_pass@&conn_str
spool logs/before_der_user_sbrext_privs_list.log
@der_user_object_privs_query.sql
spool off

-- revoke der_user SBREXT privileges
@revoke_sbrext_der_user_privs.sql

spool logs/after_der_user_sbrext_privs_list.log
@der_user_object_privs_query.sql
spool off



