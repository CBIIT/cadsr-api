set timing on

Prompt Refreshing all the SBREXT Materialized Views ...
set serveroutput on size 1000000

update definitions_view
set defl_name = 'UML Class:UML Attr'
where defl_name = 'UML Class : UML Attr';


commit;

BEGIN
  sbrext_admin_mv.refresh_mvw;
END;
/


Prompt Refresh complete
