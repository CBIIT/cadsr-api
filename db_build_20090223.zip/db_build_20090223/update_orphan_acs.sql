 -- Cleanup for Orphan ACs with missing Public ID values
 
-- DROP SEQUENCE orphan_ac_idseq;

CREATE SEQUENCE orphan_ac_idseq
  INCREMENT BY 1
  START WITH -2000
  MAXVALUE -1
  MINVALUE -2000
  NOCYCLE
  NOCACHE
  NOORDER;

UPDATE sbr.admin_components_view
   SET deleted_ind = 'Yes',
       public_id = orphan_ac_idseq.NEXTVAL
 WHERE public_id IS NULL AND actl_name != 'CLASSIFICATION';
 
COMMIT ;

DROP SEQUENCE orphan_ac_idseq;