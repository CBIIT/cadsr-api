
-- Connect as sbrext and run the following script
set define on
set scan on
set define '&'
connect sbrext/&sbrext_pass@&conn_str

set echo off
set define off
set scan off
spool logs/run_scripts_tracker18718.log
  @SBREXT_FORM_BUILDER_PKG_DEV.pkb
spool off

