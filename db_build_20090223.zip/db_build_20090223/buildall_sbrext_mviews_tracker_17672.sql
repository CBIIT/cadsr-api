-- spool buildall_sbrext_mviews_tracker_17672.log

@sbrext.up_cadsr_project_mvw.sql;
@sbrext.up_sub_projects_mvw.sql;
@sbrext.up_packages_mvw_temp.sql;
@sbrext.up_packages_mvw.sql;
@sbrext.up_class_metadata_mvw_temp.sql;
@sbrext.up_gen_metadata_mvw_18666.sql;
@sbrext.up_class_metadata_mvw.sql;
@sbrext.up_attribute_metadata_mvw_temp_4001.sql;
@sbrext.up_attribute_type_metadata_mvw.sql;
@sbrext.up_attribute_metadata_mvw_4001.sql;
@sbrext.up_type_enumeration_mvw.sql;
@sbrext.up_associations_metadata_mvw_4001.sql;
@sbrext.up_semantic_metadata_mvw.sql;

-- spool off













