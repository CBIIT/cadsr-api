  /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
  /*      Author: Nadine Azie - Ekagra Software Technologies                           */
  /*        Date: 10/15/08                                                             */
  /* Description: Feature Requests item #17103                                         */                                                                                                                                  
  /*              Create a View for UML_LOADER_DEFAULTS                                */
  /* Instructions: Run as user SBREXT                                                  */                                                                                                 
  /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
  /*  Modification History                                                             */
  /*  NAZ 10/15/2008: Creation                                                         */
  /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */


CREATE OR REPLACE FORCE VIEW sbrext.uml_loader_defaults_view (ID,
                                                              context_name,
                                                              context_version,
                                                              project_name,
                                                              project_version,
                                                              VERSION,
                                                              workflow_status,
                                                              cd_preferred_name,
                                                              cd_conte_name,
                                                              package_filter,
                                                              project_long_name,
                                                              project_description
                                                             )
AS
   SELECT u.ID, u.context_name, u.context_version, u.project_name,
          u.project_version, u.VERSION, u.workflow_status,
          u.cd_preferred_name, u.cd_conte_name, u.package_filter,
          u.project_long_name, u.project_description
     FROM sbrext.uml_loader_defaults u;
     

CREATE OR REPLACE PUBLIC SYNONYM uml_loader_defaults_view FOR sbrext.uml_loader_defaults_view;

GRANT SELECT ON sbrext.uml_loader_defaults_view TO der_user;

GRANT ALL ON sbrext.uml_loader_defaults_view TO sbr WITH GRANT OPTION;
