DROP MATERIALIZED VIEW SBREXT.UP_ASSOCIATIONS_METADATA_MVW;

CREATE MATERIALIZED VIEW sbrext.up_associations_metadata_mvw
NOCACHE
LOGGING
NOCOMPRESS
NOPARALLEL
BUILD IMMEDIATE
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS
SELECT CAST (sbr.admincomponent_crud.cmr_guid AS CHAR (36)) asm_idseq, ocr_idseq,
       t_cm_idseq, s_cm_idseq, cs_idseq, cm_idseq, cp_idseq, source_role,
       target_role, source_low_multiplicity, source_high_multiplicity,
       target_low_multiplicity, target_high_multiplicity, isbidirectional,
       gmesourcexmllocreference, gmetargetxmllocreference, VERSION, public_id,
       cs_csi_idseq, source_gmexmlelement, source_gmenamespace, target_gmexmlelement, target_gmenamespace
  FROM (SELECT DISTINCT ocr_idseq, t_cm.cm_idseq t_cm_idseq,
                        s_cm.cm_idseq s_cm_idseq, a_cm.cs_idseq,
                        a_cm.cm_idseq, cp.cp_idseq, source_role, target_role,
                        source_low_multiplicity, source_high_multiplicity,
                        target_low_multiplicity, target_high_multiplicity,
                        DECODE (direction,
                                'Bi-Directional', 1,
                                0
                               ) isbidirectional,
                        umlproject_routines.get_gmename
                             (ocr.ocr_idseq,
                              'GME_SourceXMLLocRef',
                              cscsi.cs_csi_idseq
                             ) gmesourcexmllocreference,
                        umlproject_routines.get_gmename
                             (ocr.ocr_idseq,
                              'GME_TargetXMLLocRef',
                              cscsi.cs_csi_idseq
                             ) gmetargetxmllocreference,
                        ocr.VERSION, ocr.ocr_id public_id, cscsi.cs_csi_idseq,
                        s_cm.gmexmlelement AS source_gmexmlelement,
                        s_cm.gmenamespace AS source_gmenamespace,
                        t_cm.gmexmlelement AS target_gmexmlelement,
                        t_cm.gmenamespace AS target_gmenamespace
                   FROM sbrext.oc_recs_ext ocr,
                        sbrext.up_class_metadata_mvw_temp t_cm,
                        sbrext.up_class_metadata_mvw_temp s_cm,
                        sbrext.up_class_metadata_mvw_temp a_cm,
                        sbr.ac_csi accsi,
                        sbr.cs_csi cscsi,
                        sbrext.up_cadsr_project_mvw cp
                  WHERE ocr.t_oc_idseq = t_cm.oc_idseq
                    AND ocr.s_oc_idseq = s_cm.oc_idseq
                    AND (   t_cm.cm_idseq = a_cm.cm_idseq
                         OR s_cm.cm_idseq = a_cm.cm_idseq
                        )
                    AND rl_name <> 'IS_A'
                    AND ocr.ocr_idseq = accsi.ac_idseq
                    AND cscsi.cs_csi_idseq = accsi.cs_csi_idseq
                    AND cscsi.cs_idseq = cp.cs_idseq
                    AND t_cm.cp_idseq = s_cm.cp_idseq
                    AND t_cm.cp_idseq = a_cm.cp_idseq
                    AND t_cm.cp_idseq = cp.cp_idseq);

GRANT ALTER, DELETE, INSERT, SELECT, UPDATE, ON COMMIT REFRESH, QUERY REWRITE, DEBUG, FLASHBACK ON SBREXT.UP_ASSOCIATIONS_METADATA_MVW TO DER_USER;

GRANT ALTER, DELETE, INSERT, SELECT, UPDATE, ON COMMIT REFRESH, QUERY REWRITE, DEBUG, FLASHBACK ON SBREXT.UP_ASSOCIATIONS_METADATA_MVW TO LOADER_ROLE;

GRANT ALTER, DELETE, INSERT, SELECT, UPDATE, ON COMMIT REFRESH, QUERY REWRITE, DEBUG, FLASHBACK ON SBREXT.UP_ASSOCIATIONS_METADATA_MVW TO SCHEMA_TESTER;


COMMENT ON MATERIALIZED VIEW SBREXT.UP_ASSOCIATIONS_METADATA_MVW IS 'snapshot table for snapshot SBREXT.UP_ASSOCIATIONS_METADATA_MVW';

