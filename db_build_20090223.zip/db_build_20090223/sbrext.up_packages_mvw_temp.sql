DROP MATERIALIZED VIEW SBREXT.UP_PACKAGES_MVW_TEMP;
CREATE MATERIALIZED VIEW SBREXT.UP_PACKAGES_MVW_TEMP 
TABLESPACE SBREXT
NOCACHE
LOGGING
NOCOMPRESS
NOPARALLEL
BUILD IMMEDIATE
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS 
/* Formatted on 2008/10/07 16:06 (Formatter Plus v4.8.8) */
SELECT CAST (admincomponent_crud.cmr_guid AS CHAR (36)) pg_idseq, NAME,
       description, cs_idseq, cs_csi_idseq, cp_idseq, p_cs_csi_idseq,
       gmenamespace, VERSION, public_id, package_type
  FROM (SELECT csi.long_name NAME, csi.preferred_definition description,
               cp.cs_idseq, cscsi.cs_csi_idseq, cp.cp_idseq, p_cs_csi_idseq,
               umlproject_routines.get_gmename
                                            (csi.csi_idseq,
                                             'GME_XMLNamespace',
                                             cscsi.cs_csi_idseq
                                            ) gmenamespace,
               csi.VERSION, csi_id public_id, 'Project Package' package_type
          FROM cs_csi cscsi, cs_items csi, up_cadsr_project_mvw cp
         WHERE cp.cs_idseq = cscsi.cs_idseq
           AND cscsi.csi_idseq = csi.csi_idseq
           AND csitl_name = 'UML_PACKAGE_NAME'
           AND p_cs_csi_idseq IS NULL
        UNION
        SELECT csi.long_name NAME, csi.preferred_definition description,
               cscsi.cs_idseq cs_idseq, cscsi.cs_csi_idseq, cp.cp_idseq,
               p_cs_csi_idseq,
               umlproject_routines.get_gmename
                                            (csi.csi_idseq,
                                             'GME_XMLNamespace',
                                             cscsi.cs_csi_idseq
                                            ) gmenamespace,
               csi.VERSION, csi_id public_id,
               'Sub Project Package' package_type
          FROM up_sub_projects_mvw sp,
               cs_csi cscsi,
               cs_items csi,
               up_cadsr_project_mvw cp
         WHERE cscsi.p_cs_csi_idseq = sp.cs_csi_idseq
           AND cscsi.csi_idseq = csi.csi_idseq
           AND csitl_name = 'UML_PACKAGE_NAME'
           AND cscsi.cs_idseq = cp.cp_idseq);

COMMENT ON MATERIALIZED VIEW SBREXT.UP_PACKAGES_MVW_TEMP IS 'snapshot table for snapshot SBREXT.UP_PACKAGES_MVW_TEMP';

