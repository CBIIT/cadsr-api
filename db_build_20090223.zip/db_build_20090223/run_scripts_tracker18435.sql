
-- Connect as sbrext and run the following script
set define on
set scan on
set define '&'
connect sbrext/&sbrext_pass@&conn_str

spool logs/run_scripts_tracker18435.log
  @alter_tools_options_tbl.sql
spool off

