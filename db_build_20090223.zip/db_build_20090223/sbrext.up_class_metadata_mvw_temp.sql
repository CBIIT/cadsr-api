DROP MATERIALIZED VIEW SBREXT.UP_CLASS_METADATA_MVW_TEMP;
CREATE MATERIALIZED VIEW SBREXT.UP_CLASS_METADATA_MVW_TEMP 
TABLESPACE SBREXT
NOCACHE
LOGGING
NOCOMPRESS
NOPARALLEL
BUILD IMMEDIATE
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS 
/* Formatted on 2008/10/07 16:06 (Formatter Plus v4.8.8) */
SELECT CAST (admincomponent_crud.cmr_guid AS CHAR (36)) cm_idseq,
       desig.NAME NAME, defin.definition description, oc.oc_idseq, pg_idseq,
       cscsi.cs_idseq, desig.desig_idseq, defin.defin_idseq, pg.cs_csi_idseq,
       pg.NAME || '.' || desig.NAME fully_qualified_class_name, cp.cp_idseq,
       umlproject_routines.get_gmename (oc.oc_idseq,
                                        'GME_XMLNamespace',
                                        cscsi.cs_csi_idseq
                                       ) gmenamespace,
       umlproject_routines.get_gmename (oc.oc_idseq,
                                        'GME_XMLElement',
                                        cscsi.cs_csi_idseq
                                       ) gmexmlelement,
       oc.VERSION, oc.oc_id public_id
  FROM object_classes_ext oc,
       ac_csi accsi,
       up_packages_mvw pg,
       cs_csi cscsi,
       designations desig,
       (SELECT *
          FROM definitions
         WHERE defl_name = 'UML Class') defin,
       ac_att_cscsi_ext descsi,
       ac_att_cscsi_ext defcsi,
       up_cadsr_project_mvw cp
 WHERE accsi.ac_idseq = oc.oc_idseq
   AND cscsi.cs_csi_idseq = accsi.cs_csi_idseq
   AND oc.oc_idseq = desig.ac_idseq
   AND oc.oc_idseq = defin.ac_idseq(+)
   AND descsi.att_idseq = desig.desig_idseq
   AND defcsi.att_idseq(+) = defin.defin_idseq
   AND pg.cs_csi_idseq(+) = defcsi.cs_csi_idseq
   AND pg.cs_csi_idseq = descsi.cs_csi_idseq
   AND pg.cs_csi_idseq = accsi.cs_csi_idseq
   AND desig.detl_name = 'UML Class'
   AND cscsi.cs_idseq = cp.cp_idseq
   AND pg.cp_idseq = cp.cp_idseq;

COMMENT ON MATERIALIZED VIEW SBREXT.UP_CLASS_METADATA_MVW_TEMP IS 'snapshot table for snapshot SBREXT.UP_CLASS_METADATA_MVW_TEMP';

