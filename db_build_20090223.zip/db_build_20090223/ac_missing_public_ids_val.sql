set echo on
/* Count per type, of Admin Components with missing Public IDs
   2 DE, 1 CD, 1618 QC and 27 CS  */
SELECT   actl_name, COUNT (*)
    FROM sbr.admin_components_view
   WHERE public_id IS NULL
GROUP BY actl_name;

/* Count per type, of Admin Components with missing Public IDs in the AC table
     and having corresponding records in the original tables 
   Only ACs of CS type have corresponding records in the original table 
    for the records with missing public IDs
  There are 27 ACs of CS type with missing public IDs in the AC table, and also missing
    public ID values in the original CS table. */
SELECT   actl_name, COUNT (*)
    FROM sbr.admin_components_view
   WHERE public_id IS NULL
     AND ac_idseq IN (
            SELECT de_idseq
              FROM sbr.data_elements_view
            UNION
            SELECT qc_idseq
              FROM sbrext.quest_contents_view_ext
            UNION
            SELECT cd_idseq
              FROM sbr.conceptual_domains_view
            UNION
            SELECT cs_idseq
              FROM sbr.classification_schemes_view)
GROUP BY actl_name;

SELECT 'CLASSIFICATION' AS actl_name, COUNT (*) AS missing_ids
  FROM sbr.classification_schemes_view
 WHERE cs_id IS NULL;

set echo off

