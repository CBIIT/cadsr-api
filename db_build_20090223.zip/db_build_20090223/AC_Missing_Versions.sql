-- Count per type, of Admin Components with missing Versions
SELECT actl_name, COUNT (*)
       FROM sbr.admin_components_view
       WHERE version IS NULL
      GROUP BY actl_name;

ACTL_NAME              COUNT(*)                                                 
-------------------- ----------                                                 
DATAELEMENT                   2                                                 
CONCEPTUALDOMAIN              1                                                 
QUEST_CONTENT              1618                                                 
CLASSIFICATION               27                                                 

-- Count per type, of Admin Components with missing Public IDs in the AC table
--       and having corresponding records in the original tables
SELECT actl_name, COUNT (*)
       FROM sbr.administered_components
       WHERE public_id IS NULL
           AND ac_idseq IN (
               SELECT de_idseq
                 FROM sbr.data_elements
               UNION
               SELECT qc_idseq
                 FROM sbrext.quest_contents_ext
               UNION
               SELECT cd_idseq
                 FROM sbr.conceptual_domains
               UNION
               SELECT cs_idseq
                 FROM sbr.classification_schemes)
   GROUP BY actl_name;

ACTL_NAME              COUNT(*)                                                 
-------------------- ----------                                                 
CLASSIFICATION               27  

-- Only ACs of CS type have corresponding records in the original table 
--       for the records with missing public IDs
-- So What to do with the ACs of DE, CD and QC types that do not have corresponding records
--             in the original tables?                                             

-- Count of CS type Admin Components with missing Public IDs in the AC table
--       and having corresponding records in the original tables with existing CS public IDs
SELECT COUNT (*)
       FROM sbr.administered_components
       WHERE actl_name ='CLASSIFICATION' 
           AND public_id IS NULL
           AND ac_idseq IN (
               SELECT cs_idseq
                 FROM sbr.classification_schemes 
                 WHERE cs_id is not null);
 
 COUNT(*)
---------
        0

-- So the 27 ACs of CS type with missing public IDs in the AC table, are also missing
--      public ID values in the original CS table.
--      Should we update the original CS table to add the public IDs, which will then get 
--      propagated to the AC table records?


SELECT   'CLASSIFICATION' AS actl_name, COUNT (*) AS missing_ids
    FROM sbr.classification_schemes_view
   WHERE cs_id IS NULL
UNION
SELECT   'CONCEPT' AS actl_name, COUNT (*) AS missing_ids
    FROM sbrext.concepts_view_ext
   WHERE con_id IS NULL
UNION
SELECT   'CONCEPTUAL DOMAIN' AS actl_name, COUNT (*) AS missing_ids
    FROM sbr.conceptual_domains_view
   WHERE cd_id IS NULL
UNION
SELECT   'CLASS SCHEME ITEM' AS actl_name, COUNT (*) AS missing_ids
    FROM sbr.cs_items_view
   WHERE csi_id IS NULL
UNION
SELECT   'DATA ELEMENT' AS actl_name, COUNT (*) AS missing_ids
    FROM sbr.data_elements_view
   WHERE cde_id IS NULL
UNION
SELECT   'DATA ELEMENT CONCEPT' AS actl_name, COUNT (*) AS missing_ids
    FROM sbr.data_element_concepts_view
   WHERE dec_id IS NULL
UNION
SELECT   'OBJECT CLASS' AS actl_name, COUNT (*) AS missing_ids
    FROM sbrext.object_classes_view_ext
   WHERE oc_id IS NULL
UNION
SELECT   'OBJECT CLASS RECS' AS actl_name, COUNT (*) AS missing_ids
    FROM sbrext.oc_recs_view_ext
   WHERE ocr_id IS NULL
UNION
SELECT   'PROPERTY' AS actl_name, COUNT (*) AS missing_ids
    FROM sbrext.properties_view_ext
   WHERE prop_id IS NULL
UNION
SELECT   'PROTOCOL' AS actl_name, COUNT (*) AS missing_ids
    FROM sbrext.protocols_view_ext
   WHERE proto_id IS NULL
UNION
SELECT   'QUEST CONTENT' AS actl_name, COUNT (*) AS missing_ids
    FROM sbrext.quest_contents_view_ext
   WHERE qc_id IS NULL
UNION
SELECT   'REPRESENTATION' AS actl_name, COUNT (*) AS missing_ids
    FROM sbrext.representations_view_ext
   WHERE rep_id IS NULL
UNION
SELECT   'VALUE DOMAIN' AS actl_name, COUNT (*) AS missing_ids
    FROM sbr.value_domains_view
   WHERE vd_id IS NULL
UNION
SELECT   'VALUE MEANING' AS actl_name, COUNT (*) AS missing_ids
    FROM sbr.value_meanings_view
   WHERE vm_id IS NULL
ORDER BY actl_name;

ACTL_NAME            MISSING_IDS
-------------------- -----------
CLASS SCHEME ITEM              0
CLASSIFICATION                27
CONCEPT                        0
CONCEPTUAL DOMAIN              0
DATA ELEMENT                   0
DATA ELEMENT CONCEPT           0
OBJECT CLASS                   0
OBJECT CLASS RECS              0
PROPERTY                       0
PROTOCOL                       0
QUEST CONTENT                  0

ACTL_NAME            MISSING_IDS
-------------------- -----------
REPRESENTATION                 0
VALUE DOMAIN                   0
VALUE MEANING                  0
