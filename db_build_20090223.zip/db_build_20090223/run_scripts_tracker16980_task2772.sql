
set echo off
set define on
set scan on
set define '&'
prompt Please enter database SID
define conn_str = &conn_str
prompt Please enter SBR password
define sbr_pass = &sbr_pass
prompt Please enter SBREXT password
define sbrext_pass = &sbrext_pass


-- Connect as sbr and run the following scripts
set define on
set scan on
set define '&'
connect sbr/&sbr_pass@&conn_str
set define off
@invalid.sql
spool run_scripts_tracker16980_task2772_SBR.log
@validate_query.sql
@sbr_drop_invalid_code.sql
@validate_query.sql
spool off

-- Connect as sbrext and run the following scripts
set define on
set scan on
set define '&'
connect sbrext/&sbrext_pass@&conn_str
set define off
@invalid.sql
spool run_scripts_tracker16980_task2772_SBREXT.log
@Refresh_Mviews.sql
@validate_query.sql
@sbrext_drop_invalid_code.sql
@validate_query.sql
spool off




