/* Update the 27 ACs of CS type with missing public IDs in the AC table, and also missing
    public ID values in the original CS table.  */
    
UPDATE sbr.classification_schemes_view
   SET cs_id = cde_id_seq.NEXTVAL
 WHERE cs_id IS NULL;

COMMIT ;
