
-- Connect as sbrext and run the following script
set define on
set scan on
set define '&'
connect sbrext/&sbrext_pass@&conn_str

set echo off
set define off
set scan off
spool logs/run_scripts_tracker17103.log
  @cr_uml_loader_def_view.sql
spool off

