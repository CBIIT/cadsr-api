
-- Connect as sbr and run the following script

set echo off
set define off
set scan off

-- spool logs/run_scripts_tracker21938.log
  @GF21938/CSCSI_INSERT$DETAIL_NEW.pkb
  @GF21938/CSCSI_INSERT$JS$DETAIL_NEW.pkb
  @GF21938/CSCSI_DETAIL_IRUD$JS$DETAIL_NEW.pkb
  @GF21938/CSCSI_DETAIL_IRUD$DETAIL_NEW.pkb

set define on
set scan on
-- spool off

