
-- Connect as sbr and run the following script
set define on
set scan on
set define '&'
connect sbr/&sbr_pass@&conn_str

set echo off
set define off
set scan off

spool logs/install_admin_tool_patch_401.log
  @META_UI.pkb
  
set define on
set scan on
spool off

set echo on
spool logs/update_admin_tool_release_version.log

UPDATE ui_metadata_view
SET host = '4.0.1'
WHERE name = 'RELEASE';
COMMIT;

spool off


