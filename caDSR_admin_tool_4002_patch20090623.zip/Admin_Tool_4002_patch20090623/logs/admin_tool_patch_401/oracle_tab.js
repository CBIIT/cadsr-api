//-- Copy data from the top
if (top.toprow) var toprow = top.toprow
if (top.tab) var tab = top.tab
if (top.TopMaxVal) var TopMaxVal = top.TopMaxVal
if (top.TabMaxVal) var TabMaxVal = top.TabMaxVal
if (top.strings) var strings = top.strings

var def_header		  = '0'
var header      = top.header
if (!header) header = def_header

var crumb = ""
if (top.crumb) crumb = top.crumb
var URL = top.location

function Is ()
{   // convert all characters to lowercase to simplify testing
    var agt=navigator.userAgent.toLowerCase()

    // --- BROWSER VERSION ---
    this.major = parseInt(navigator.appVersion)
    this.minor = parseFloat(navigator.appVersion)

    this.nav  = ((agt.indexOf('mozilla')!=-1) && ((agt.indexOf('spoofer')==-1)
                && (agt.indexOf('compatible') == -1)))
    this.nav2 = (this.nav && (this.major == 2))
    this.nav3 = (this.nav && (this.major == 3))
    this.nav4 = (this.nav && (this.major == 4))

    this.ie   = (agt.indexOf("msie") != -1)
    this.ie3  = (this.ie && (this.major == 2))
    this.ie4  = (this.ie && (this.major == 4))

    this.opera = (agt.indexOf("opera") != -1)
     
    this.nav4up = this.nav && (this.major >= 4)
    this.ie4up  = this.ie  && (this.major >= 4)
}


var is = new Is();

function getElt () 
{
 if (this.nav4up) {
    var currentLayer = document.layers[getElt.arguments[0]];
    for (var i=1; i<getElt.arguments.length && currentLayer; i++)
    {   currentLayer = currentLayer.document.layers[getElt.arguments[i]];
    }
    return currentLayer;
  } 
  else if (is.ie4up) {
    var elt = eval('document.all.' + getElt.arguments[getElt.arguments.length-1]);
    return(elt);
  }
}

function show(object) {
    if (document.getElementById && document.getElementById(object) != null) {
         document.getElementById(object).style.visibility='visible';
         document.getElementById(object).style.display='block';
    }
    else if (document.layers && document.layers[object] != null) {
        document.layers[object].visibility = 'visible'; }
    else if (document.all) {
        document.all[object].style.zIndex = 100;
        document.all[object].style.visibility = 'visible';
    }
}

function hide(object) {
    if (document.getElementById && document.getElementById(object) != null) {
         document.getElementById(object).style.visibility='hidden';
         document.getElementById(object).style.display='none';
    }
    else if (document.layers && document.layers[object] != null)
        document.layers[object].visibility = 'hidden';
    else if (document.all)
         document.all[object].style.visibility = 'hidden';
}

function DrawTab( Label, Index, Type, Img ) {
  var Off_Color = '#666699'
  var On_Color = '#FFF794'

  if ( Img ) {
    Str  = '<td nowrap height=19 bgcolor="white">';
    Str +=   '<a href="javascript:tabClick('+Index+')"><img src=/images/transparent_pixel.gif width=10 border=0><img src="'+Img+'" border=0></a>';
    Str += '</td>';

    document.write(Str);
    return;
  }

  if ( !Type ) Type = 'Off'  

  if ( Type == 'First On' ) {
    Str =  '<td nowrap height=19 bgcolor="'+On_Color+'">'
    Str +=    '<img src="/images/slant.gif" width=11 height=19 border=0 alt=" ">'
    Str += '</td>'
    Str += '<td nowrap height=19 align=CENTER valign=BOTTOM bgcolor="' + On_Color + '">'
    Str += '&nbsp;<a class="OnTab" href="javascript:tabClick('+Index+')">'+Label+'</a>'
    Str += '</td>'
    Str += '<td nowrap height=19 bgcolor="'+On_Color+'">'
    Str +=    '<img src="/images/rightcurve.gif" width=10 height=19 border=0 alt="">'
    Str += '</td>'
  } else if ( Type == 'First Off' ) {
    Str =  '<td nowrap height=19 bgcolor="'+Off_Color+'">'
    Str +=   '<img src="/images/slant.gif" width=11 height=19 border=0 alt="">'
    Str += '</td>'
    Str += '<td nowrap align="CENTER" valign="MIDDLE" bgcolor="'+Off_Color+'">'
    Str +=   '&nbsp;<a class="OffTab" href="javascript:tabClick('+Index+')">'+Label+'</a>'
    Str += '</td>'
    Str += '<td nowrap height=19 bgcolor="'+Off_Color+'">'
    Str +=   '<img src="/images/rightcurve.gif" width=10 height=19 border=0 alt=" ">'
    Str += '</td>'
  } else if ( Type == 'Off' ) {
    Str  = '<td nowrap height=19 bgcolor="'+Off_Color+'">'
    Str +=   '<img src="/images/leftoverlap_off.gif" width=10 height=19 border=0 alt="">'
    Str += '</td>'
    Str += '<td nowrap align="CENTER" valign="MIDDLE" bgcolor="'+Off_Color+'">'
    Str +=   '&nbsp;<a class="OffTab" href="javascript:tabClick('+Index+')">'+Label+'</a>'
    Str += '</td>'
    Str += '<td nowrap height=19 bgcolor="'+Off_Color+'">'
    Str +=   '<img src="/images/rightcurve.gif" width=10 height=19 border=0 alt=" ">'
    Str += '</td>'
  } else if ( Type == 'Before On' ) {
    Str  = '<td nowrap height=19 bgcolor="'+Off_Color+'">'
    Str +=   '<img src="/images/leftoverlap_off.gif" width=10 height=19 border=0 alt="">'
    Str += '</td>'
    Str += '<td nowrap align="CENTER" valign="MIDDLE" bgcolor="'+Off_Color+'">'
    Str +=   '&nbsp;<a class="OffTab" href="javascript:tabClick('+Index+')">'+Label+'</a>'
    Str += '</td>'
    Str += '<td nowrap height=19 bgcolor="'+On_Color+'">'
    Str +=   '<img src="/images/split_right.gif" width=10 height=19 border=0 alt="">'
    Str += '</td>'
  } else if ( Type == 'On' ) {
    Str  = '<td nowrap height=19 bgcolor="'+On_Color+'">'
    Str +=   '<img src="/images/split_left.gif" width=10 height=19 border=0 alt="">'
    Str += '</td>'
    Str += '<td nowrap align="CENTER" valign="MIDDLE" bgcolor="'+On_Color+'">'
    Str +=   '&nbsp;<a class="OnTab" href="javascript:tabClick('+Index+')">'+Label+'</a>'
    Str += '</td>'
    Str += '<td nowrap height=19 bgcolor="'+On_Color+'">'
    Str +=   '<img src="/images/rightcurve.gif" width=10 height=19 border=0 alt="">'
    Str += '</td>' 
  }
    
  document.write( Str );
}

function DrawTabRow(active) {
  var OnTab;

  for (OnTab=0; OnTab < tab.length + 1; OnTab++) {
    document.write('<div id="tab' + OnTab + '">');
    document.write('<table border=0 cellspacing=0 cellpadding=0><tr>');

    if (tab_title)
        document.write('<td class="tabTitle">'+tab_title+'<img src="/images/transparent_pixel.gif" height="1" width="120"></td>');

    if ( OnTab == 0 ) {
      DrawTab( tab[0].label, 0, 'First On', tab[0].dspimg); }
    else {
      DrawTab( tab[0].label, 0, 'First Off', tab[0].dspimg); }

    for (var i = 1; i < tab.length; i++) {
      if ( i == OnTab ) {
        DrawTab( tab[i].label, i, 'On', tab[i].dspimg ); } 
      else {
        if ( i == OnTab-1 && OnTab < tab.length){
          DrawTab( tab[i].label, i, 'Before On', tab[i].dspimg ); } 
        else {
          DrawTab( tab[i].label, i, 'Off', tab[i].dspimg ); }
      }
    }

    document.write('<td>&nbsp;</td>');
    document.write('</tr></table>' );
    document.write('</div>');
  }

//  document.write('<div id=tabUndL><table width=100% border=0 cellspacing=0 cellpadding=0 height=2 bgcolor=#666699><tr><td><img src="/images/transparent_pixel.gif" height=2 width=1></td></tr></table></div>');

  for(i=0;i<tab.length+1;i++)
    if (document.layers)
      document.layers["tab"+i].left=window.innerWidth - document.layers["tab"+i].clip.width - 40;
    else
      document.all["tab"+i].style.pixelLeft = document.body.clientWidth - document.all["tab"+i].scrollWidth - 40;

//  if (document.layers) {
//    document.layers["tabUndL"].top=document.layers["tab0"].top+document.layers["tab0"].clip.height;
//  } else {
//    document.all["tabUndL"].style.top=document.all["tab0"].style.top+29;
//  }

  if (active) {
    show("tab" + active); }
  else {
    show("tab0"); }
}

function setActive(actlabel) {
  for (i=0; i < tab.length+1; i++)
     hide("tab"+i);

  if (! actlabel)
    return;

  for (var i = 0; i < tab.length; i++)
    if (tab[i].label == actlabel) {
       show("tab"+i);

       header = i;
       return;
    }
  show("tab"+tab.length);
}

var frm;

function findFrameByName(strName) {
 findFrame(top.frames, strName);
}

function findFrame(frmFrames, strName) {
  if (frmFrames.length == 0) return;

  for (var i = 0; i < frmFrames.length; i++) {
    if (frmFrames[i].name == strName) {
      frm=frmFrames[i];
      return;
    }

    if (frmFrames[i].frames.length != 0) {
      findFrame(frmFrames[i].frames,strName);

      if ( frm  )
        return;
    }
  }
}
 
function tabClick(item) {
  for (i=0; i < tab.length; i++)
     hide("tab"+i);

  show("tab"+item);

  if (tab[item].url) {
    // If the item has its own target, use it instead of the
    // tabstrip default.

    if (tab[item].target)
      findFrameByName(tab[item].target);
    else
      findFrameByName(tab_target);

    if (!frm) {
       document.location = tab[item].url; }
    else {
       frm.document.location = tab[item].url;
    }
  }
}

function regenerateTab () {
  document.location.href=document.location.href;
 }

// Define the tabItem and associated properties.

tabItem.prototype.label  = "dummy";
tabItem.prototype.url    = null;
tabItem.prototype.dspimg = null;
tabItem.prototype.target = null;

function tabItem(inLabel, inUrl, inImg, inTarg)
  {
    if (!inLabel) return;

    this.label  = inLabel;

    if (inUrl != "") this.url = inUrl;

    this.dspimg = inImg;
    this.target = inTarg;
  }
