
-- Connect as sbr and run the following script
set define on
set scan on
set define '&'
connect sbr/&sbr_pass@&conn_str

set echo off
set define off
set scan off

spool logs/install_admin_tool_4002_patch20090623.log
  @GF21938/run_scripts_tracker21938.sql
  
set define on
set scan on
spool off

