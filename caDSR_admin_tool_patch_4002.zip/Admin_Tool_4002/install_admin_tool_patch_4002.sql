
-- Connect as sbrext and run the following script
set define on
set scan on
set define '&'
connect sbrext/&sbrext_pass@&conn_str

set echo off
set define off
set scan off

spool logs/install_admin_tool_patch_4002.log
  @GF19987/CSI_BASICSEARCH_CSI_new.pkb
  
set define on
set scan on
spool off

